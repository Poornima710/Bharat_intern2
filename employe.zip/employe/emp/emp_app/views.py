# demo/views.py
from django.shortcuts import render

def home(request):
    # Set a cookie
    response = render(request, 'home.html')
    response.set_cookie('my_cookie', 'cookie_value')
    return response
